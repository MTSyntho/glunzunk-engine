
	import * as THREE from 'three';
	import { gzjs } from './../../engine/glunzunk.js';

	function startScript() {
		// setInterval(function() {}, 1); // placeholder
		setInterval(function() {
	gzjs.object('table').rotation.x += 0.0001
}, 1);

	};

	export { startScript };
  