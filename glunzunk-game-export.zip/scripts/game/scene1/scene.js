
	import { gzjs } from './../../engine/glunzunk.js';
	import { startScript } from './script.js';

	function startScene() {
  gzjs.lighting('hemisphere', 5, 0xffffff, 0x4e4e4e);gzjs.shadow(true, 'PCFSoft');gzjs.tonemapping('cineon', 0.5);gzjs.fog('expo', 0xcccccc, 0.0015);gzjs.sky(
  			11.4,
  			3,
  			0.004,
  			0.619,
  			0,
  			180,
  			450000,
  			0xffffff,
  			10,
  			true
  		);
    	gzjs.newObject(
    	    'table',
    	    'box',
    	    0x005000,
    	    [0,-0.5275658830432868,0],
    	    {"width":6.844421128459028,"height":0.21964475986917992,"depth":2.828087873849297,"widthSegments":1,"heightSegments":1,"depthSegments":1}, 
    	    'standard',
    	    {},
			{ textures: { map: gzjs.texture(''),aoMap: gzjs.texture(''),normalMap: gzjs.texture(''),roughnessMap: gzjs.texture(''),displacementMap: gzjs.texture(''), } }
    	);
    	gzjs.newObject(
    	    'bean',
    	    'capsule',
    	    0x00ffff,
    	    [-0.42401371462670595,0.42257671772849703,0],
    	    {"radius":0.5,"length":0.7,"capSegments":10,"radialSegments":20}, 
    	    'standard',
    	    {},
			{ textures: { map: gzjs.texture(''),aoMap: gzjs.texture(''),normalMap: gzjs.texture(''),roughnessMap: gzjs.texture(''),displacementMap: gzjs.texture(''), } }
    	);
    	gzjs.newObject(
    	    'beanbut2',
    	    'capsule',
    	    0xff00ff,
    	    [0.4799993951509566,0.001967521296868613,0.09506776934243644],
    	    {"radius":0.3,"length":0.5,"capSegments":3,"radialSegments":5}, 
    	    'standard',
    	    {},
			{ textures: { map: gzjs.texture(''),aoMap: gzjs.texture(''),normalMap: gzjs.texture(''),roughnessMap: gzjs.texture(''),displacementMap: gzjs.texture(''), } }
    	);
		var loading = document.getElementById('loading-screen');
		loading.style.display = 'none';
		loading.style.pointerEvents = 'none';

		startScript();
	};

	export { startScene }
  